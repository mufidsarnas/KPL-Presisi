﻿using System;
using System.Text.RegularExpressions;

// Base class
public class BaseUser
{
    public string Username { get; set; }
    public string Password { get; set; }
}

// Generic class dengan constraint
public class User<T> where T : BaseUser, new()
{
    public T[] Users = new T[100];
    private int count = 0;

    public bool AddUser(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
        {
            Console.WriteLine("Input username dan password dengan benar.\n");
            return false;
        }

        if (!IsValidUsername(username))
        {
            Console.WriteLine("Username harus huruf kecil semua (a-z).\n");
            return false;
        }

        if (IsUsernameTaken(username))
        {
            Console.WriteLine("Username sudah digunakan. Silakan pilih username lain.\n");
            return false;
        }

        if (!IsValidPassword(password))
        {
            Console.WriteLine("Password harus minimal 8 karakter.\n");
            return false;
        }

        Users[count++] = new T { Username = username, Password = password };
        Console.WriteLine("Registrasi berhasil!\n");
        return true;
    }

    public bool Login(string username, string password)
    {
        for (int i = 0; i < count; i++)
        {
            if (Users[i].Username == username && Users[i].Password == password)
            {
                Console.WriteLine("Login berhasil!\n");
                return true;
            }
        }
        Console.WriteLine("Login gagal. Username atau password salah.\n");
        return false;
    }

    private bool IsValidUsername(string username)
    {
        foreach (char c in username)
        {
            if (c < 'a' || c > 'z') return false;
        }
        return true;
    }

    private bool IsUsernameTaken(string username)
    {
        for (int i = 0; i < count; i++)
        {
            if (Users[i].Username == username)
            {
                return true;
            }
        }
        return false;
    }

    private bool IsValidPassword(string password)
    {
        return password.Length >= 8;
    }
}

// Program utama
class Program
{
    static void Main(string[] args)
    {
        User<BaseUser> system = new User<BaseUser>();
        while (true)
        {
            Console.WriteLine("1. Register");
            Console.WriteLine("2. Login");
            Console.WriteLine("3. Exit");
            Console.Write("Pilih menu: ");

            string choice = Console.ReadLine();
            Console.WriteLine();

            if (choice == "1")
            {
                Console.Write("Masukkan username: ");
                string username = Console.ReadLine();
                Console.Write("Masukkan password: ");
                string password = Console.ReadLine();
                system.AddUser(username, password);
            }
            else if (choice == "2")
            {
                Console.Write("Masukkan username: ");
                string username = Console.ReadLine();
                Console.Write("Masukkan password: ");
                string password = Console.ReadLine();
                system.Login(username, password);
            }
            else if (choice == "3")
            {
                break;
            }
            else
            {
                Console.WriteLine("Pilihan tidak valid.\n");
            }
        }
    }
}
