﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTesting.Tests
{
    // Pastikan namespace-nya sesuai
    [TestClass]
    public class UserTests
    {
        private User<BaseUser> userSystem;

        [TestInitialize]
        public void Setup()
        {
            userSystem = new User<BaseUser>();
        }

        [TestMethod]
        public void AddUser_WithValidData_ShouldSucceed()
        {
            bool result = userSystem.AddUser("johnsmith", "password123");
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void AddUser_WithEmptyUsername_ShouldFail()
        {
            bool result = userSystem.AddUser("", "password123");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void AddUser_WithEmptyPassword_ShouldFail()
        {
            bool result = userSystem.AddUser("johnsmith", "");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void AddUser_WithUppercaseUsername_ShouldFail()
        {
            bool result = userSystem.AddUser("JohnSmith", "password123");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void AddUser_WithShortPassword_ShouldFail()
        {
            bool result = userSystem.AddUser("johnsmith", "12345");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void AddUser_WithDuplicateUsername_ShouldFail()
        {
            userSystem.AddUser("johnsmith", "password123");
            bool result = userSystem.AddUser("johnsmith", "anotherpass");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Login_WithCorrectCredentials_ShouldSucceed()
        {
            userSystem.AddUser("johnsmith", "password123");
            bool result = userSystem.Login("johnsmith", "password123");
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Login_WithWrongPassword_ShouldFail()
        {
            userSystem.AddUser("johnsmith", "password123");
            bool result = userSystem.Login("johnsmith", "wrongpass");
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Login_WithNonExistentUsername_ShouldFail()
        {
            bool result = userSystem.Login("nonexistent", "password123");
            Assert.IsFalse(result);
        }
    }
}
